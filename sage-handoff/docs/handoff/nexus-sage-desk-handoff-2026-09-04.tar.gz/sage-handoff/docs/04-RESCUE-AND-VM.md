# Rescue paths and persistent-VM layout

## Reality check

The polished App Builder tree is **not** in GitHub `specimba/NEXUS_SAGE`. That repo is a July 2026 Python evidence/governance product (`docs/authority-model.md`, observe-only edge envelopes). Useful as a *naming and hygiene cousin*. It will not restore `desk.tsx`.

Closest public aesthetic cousin: `specimba/NEXUS_FALLOUT_OS` (phosphor / Fallout CLI). Steal tokens, not news logic.

## Rescue order (highest yield first)

1. **This pack + current `/workspace/src` + `/workspace/attachments`.** Copy off the sandbox immediately.
2. **Grok chat export** of “NEXUS SAGE digest LANE” / GROK DAILY DIGEST. The thread contains the lost module names, test names, and pin copy.
3. **Operator local Windows** (`speci.000`): search `sage-desk.mp3`, `og.jpg`, `cycle.ts`, `desk.tsx`. If the user ever downloaded a pack JSON, that is canonicaler than memory.
4. **Zo / Docker MCP machine**: only if someone rsynced the sandbox. Unlikely for App Builder.
5. **Netlify / Vercel connectors**: only if a prior turn published. Check those accounts before rebuilding pixels from scratch.
6. **Do not** scrape `specimba/NEXUS_SAGE` expecting the desk.

## Attachments that must travel with this pack

| File | Why |
|---|---|
| `openAIandHFsandboxOUTincidentCHATGPT56SOLconvo14.txt` | 1.2 MB dump that became Digest library |
| `openAIandHFsandboxOUTincidentCHATGPT56SOLconvo14grokLANE.txt` | Grok-lane cut of same incident |
| `omp-session-2026-09-01T01-05-28-060Z_….html` | OMP / Gemini-side digest automation log — inspiration for bonds |
| `fancyTWEETScuration0209.txt` | 02 Sep URL list |
| `chrome_*.png` | Proof of aborted turns / stopped preview |

## Recommended VM layout

```
nexus-sage-desk/
  README.md                 ← 00-README from this pack
  docs/handoff/             ← this directory
  attachments/              ← copies of the six files above
  artifacts/sage/
    CURRENT.json
    cycles/003.json
    crawls/
    voice/
  src/                      ← start from the lean rebuild, then thicken
  public/og.jpg             ← regenerate 1200×630 SAGE lockup
  public/favicon.svg
  public/sage-desk.mp3
  skills/
    sage-cycle-compiler/
    sage-digest-pack/
    skill-diagnostics/
```

Init git on first clone. Tag `v0.3.0-rebuild` as the lean tree. Tag `v0.3.1` when tests from the spec are restored.

## Process on the VM

- Compiler is a scheduled job every 6h (systemd timer or the Automations connector). Human still locks numbers and hrefs.
- Ingest: Grok/X tools + `https://huggingface.co/api/daily_papers`. No XAI_API_KEY requirement. No X Ads.
- Preview: ordinary Node. `startup.sh` is only for App Builder revive.
- Persist `CURRENT.json` and crawl snapshots in git so a container recreate cannot happen again silently.

## What “done” looks like on the VM

- Brief shows 3 labeled pins, wave footer, ALLOW/DENY, two open questions.
- Pulse stamp < 18h, media cards present, rumor tags visible.
- Digest plan is executable (evidence + steps + unlock-if), not four MOVE lines.
- Voice plays a podcast mix with a volume meter.
- `npm test` covers hygiene + compiler + hydrate + digest cadence.
- Cycle 004 does not exist until a new HF/METR primary does.
